package com.greatlearning.collegefest.service;

import java.util.List;
import com.greatlearning.collegefest.Student;

public interface StudentService {

	public List<Student> findAll();
	public void save(Student thestudent);
	public void deleteById(int theId);
	public Student findById(int theId);
	
}
