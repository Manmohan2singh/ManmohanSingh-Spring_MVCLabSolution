package com.greatlearning.collegefest.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.greatlearning.collegefest.entity.Student;

@Repository
@Transactional
public class StudentRepo {

	private SessionFactory sessionFactory;
	private Session session;

	@Autowired
	StudentRepo(SessionFactory sessionFactory) {
		try {
			session = sessionFactory.getCurrentSession();
		} catch (HibernateException e) {
			session = sessionFactory.openSession();
		}
	}

	@Transactional
	public void save(Student student) {
		session.saveOrUpdate(student);
	}

	@Transactional
	public void deleteStudent(int studentId) {
		try {
			session.beginTransaction();
			Student student = session.get(Student.class, studentId);
			session.delete(student);
			session.getTransaction().commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		}
	}

	@Transactional
	public List<Student> showStudentList() {
		List<Student> studentList = session.createQuery("from Student").list();
		return studentList;
	}

	@Transactional
	public Student findById(int studentId) {
		Student student = session.get(Student.class, studentId);
		return student;
	}
}
