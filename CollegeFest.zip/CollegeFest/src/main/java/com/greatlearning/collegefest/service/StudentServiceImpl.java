package com.greatlearning.collegefest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.greatlearning.collegefest.dao.StudentRepo;
import com.greatlearning.collegefest.entity.Student;

@Service
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	StudentRepo studentRepo;

	@Override
	public List<Student> findAll() {
		List<Student> studentList = studentRepo.showStudentList();
		return studentList;
	}

	@Override
	public void save(Student thestudent) {
		studentRepo.save(thestudent);
		
	}

	@Override
	public void deleteById(int theId) {
		studentRepo.deleteStudent(theId);
		
	}

	@Override
	public Student findById(int theId) {
		Student student = studentRepo.findById(theId);
		return student;
	}

}
